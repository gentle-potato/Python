import mypack.pack1.module11
import mypack.pack1.module11 as mm1
from mypack.pack1.module11 import *

# mypack.pack1.module11.func11()
mm1.func11()
func111()