# module22.py

def func22():
    print('func22')
