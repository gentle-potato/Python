# module21.py

def func21():
    print('func21')
