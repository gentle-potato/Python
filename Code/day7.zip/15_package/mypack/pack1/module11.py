# module11.py

def func11():
    print('func11')

def func111():
    print('func111')