# module12.py

def func12():
    print('func12')

def func122():
    print('func122')
