# module32.py

def func32():
    print('func32')
