# module31.py

def func31():
    print('func31')
