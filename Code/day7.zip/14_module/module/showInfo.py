# showInfo module

def show_name():
    print('홍길동')

def show_phone():
    print('010-1111-1111')
