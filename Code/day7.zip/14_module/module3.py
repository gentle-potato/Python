
import moduleMain

print(moduleMain.getName())
moduleMain.main()
