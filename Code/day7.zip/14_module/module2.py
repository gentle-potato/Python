# calculator module 참조
# import calculator
# import showInfo  # 모듈내 모든 함수 참조
# from showInfo import show_name
from showInfo import *
# from calculator import div, add, mul
from calculator import *

# a = calculator.add(9, 8)
# print(a)
# print(calculator.mul(10,5))
print(add(5,2))
print(div(3,5))

#showInfo.show_name()
show_name()
show_phone()
