# eval() : 입력된 문자열에 해당하는 숫자형으로 변환
'''
num1 = eval(input('number1 :'))
num2 = eval(input('number2 :'))
print(type(num1))
print(type(num2))
total = num1 + num2
print('합은 {}'.format(total))
'''
print(eval(input()))

# =  : assign
# print(), format(), input(), type(), id()  del
# escape  \n  \t  \\  \"  \'
# r \n
# import
# 주석문 , 문자열
# bin(), oct(), hex(), int(), str(), float(), eval()