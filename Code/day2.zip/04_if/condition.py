# 키보드로 입력받은 정수가 짝수인지 홀수인지?

number = int(input('정수를 입력하세요! '))
'''
if(number % 2 == 0):
    print('짝수')
else:
    print('홀수')
    print('hahah')
'''
if(number % 2 == 0):
    print('짝수')
else:
    pass

# 1~10까지의 정수 합계 계산
