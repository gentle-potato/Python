# while 구문 이해 :조건이 만족하는(True) 동안만 반복문을 수행
# 1~10까지의 정수를 출력

n = 1
while n<=10:
    print(n)
    n = n + 1
