# in
string = 'Python programming'

print('Python' in string)

if 'Python' in string :
    print('있습니다.')
else:
    print('없습니다')

# in과 list

names = ['홍길동', '변학도', '성춘향', '이몽룡']
name = input('input name:')
if name in names:
    print('있다')
else:
    print('없다')