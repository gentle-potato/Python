# range(start, stop, sep)

for i in range(10):
    print(i, end=' ')

print('\n----------')

for i in range(1,10):
    print(i, end=' ')

print('\n----------')

for i in range(2,11,2):
    print(i, end=' ')

print('\n----------')

for i in range(12,1,-3):
    print(i, end=' ')

print('\n----------')
