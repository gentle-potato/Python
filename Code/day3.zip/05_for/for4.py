# 다중 for (중첩)

for i in range(4):
    for j in range(5):
        print(j, end=' ')

    print()