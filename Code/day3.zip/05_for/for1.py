# for문의 이해

for name in ['홍길동', '성춘향', '변학도', '이몽룡']:
    print(name)

for num in range(0,10):
    # print(num)
    print(num, end=' ')
print('\n======================')
for num in [1,2,3,4,5,6,7,8,9,10]:
    print(num, end=' ')

