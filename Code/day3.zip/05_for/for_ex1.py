# 1에서 100까지의 합 구하기
total = 0

for n in range(1, 101):
    total += n

print('1 ~ 100 합 : %d' % total)