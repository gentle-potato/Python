# 1~10 사이의 수를 더하고 더한 결과 출력

#sum = 0
#sum = sum + n

total = 0
for n in range(1,11):
    total = total + n
print('합은 %d' % total)


