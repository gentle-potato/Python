# extend() : append()  insert()

a = [3, 6, 0, -4, 1]
b = [40, 30, 20, 50]
# a.append(b)
# print(a)
# a.insert(2, b)
# print(a)
a.extend(b)
print(a)
