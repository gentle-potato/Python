# 리스트의 요소를 정렬 : sort() reverse() / sorted()함수

a = [3, 6, 0, -4, 1]
print(a)
# a.sort()
# a.sort(reverse=True)
# a.reverse()
# print(a)

# reverse() 메소드를 사용하지 않고 리스트를 역순으로 생성하여 출력하기
# b = []
# for i in range(len(a)):
#     # item=a.pop()
#     # print(item)
#     # b.append(item)
#     b.append(a.pop())
# print(a)
# print(b)
#
# a = [3, 6, 0, -4, 1]
# # sorted() 함수
# c = sorted(a)
# print(a)
# print(c)

string = ['GRAPE', 'Apple', 'aPPle', 'banana', 'melon', 'apple']
# string.sort(key=str.lower)
# string.sort()
# print(string)

# max(), min()함수
a = [3, 6, 0, -4, 1]

print(max(a))
print(min(a))

print(max(string))
print(min(string))


