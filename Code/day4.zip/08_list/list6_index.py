# index()메소드

a = [3, 6, 0, -4, 1]
b = a.index(-4)
print(b)

# in / not in
if 2 not in a:
    print('Not Exist')
else:
    print('Exist!')