# join()

a = 'aa'
print(a.join('bbb'))

b = '-'
print(b.join('1234'))

numbers =['10','20','30','40','50']
sep =','
result = sep.join(numbers)
print(result)

date = ['1990','01','01']
sep = '-'
print(sep.join(date))